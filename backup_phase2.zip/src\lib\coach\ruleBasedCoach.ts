import {
  CoachCapability,
  StructuredCoachExplanation,
  StructuredPriorityResponse,
  StructuredDoubtResponse,
  StructuredMistakeAnalysisResponse,
  StructuredQuizResponse,
  StructuredWeakTopicPlanResponse,
  StructuredSkillPlanResponse,
} from './types';
import { SanitizedContext } from './contextBuilder';

/**
 * Deterministic Rule-Based Fallback Coach
 * Operates with 100% offline reliability with zero AI API keys required.
 * Implements strict prioritization hierarchy:
 * 1. Maths incomplete today (<60 mins)
 * 2. Revision overdue (+1d, +3d, +7d)
 * 3. Upcoming exam urgency
 * 4. Unresolved high-priority doubt
 * 5. Lowest recent accuracy
 * 6. Repeated mistake
 * 7. Study-time deficit
 */
export class RuleBasedCoach {
  public static execute(
    capability: CoachCapability,
    sanitized: SanitizedContext
  ):
    | StructuredCoachExplanation
    | StructuredPriorityResponse
    | StructuredDoubtResponse
    | StructuredMistakeAnalysisResponse
    | StructuredQuizResponse
    | StructuredWeakTopicPlanResponse
    | StructuredSkillPlanResponse
    | Record<string, unknown> {
    switch (capability) {
      case 'explain_topic':
        return this.explainTopic(sanitized.data);
      case 'recommend_priorities':
        return this.recommendPriorities(sanitized.data);
      case 'explain_doubt':
        return this.explainDoubt(sanitized.data);
      case 'analyze_mistake':
        return this.analyzeMistake(sanitized.data);
      case 'generate_quiz':
        return this.generateQuiz(sanitized.data);
      case 'weekly_review':
        return this.conductWeeklyReview(sanitized.data);
      case 'weak_topic_plan':
        return this.generateWeakTopicPlan(sanitized.data);
      case 'skill_lab_plan':
        return this.generateSkillPlan(sanitized.data);
      case 'socratic_question':
        return this.socraticQuestion(sanitized.data);
      default:
        return this.recommendPriorities(sanitized.data);
    }
  }

  // 0. EXPLAIN TOPIC (Offline deterministic baseline)
  private static explainTopic(data: Record<string, unknown>): StructuredCoachExplanation {
    const question = String(data.question || 'Academic concept');
    const subject = String(data.subject || 'General Science');
    const chapter = String(data.chapter || 'Core Chapter');
    const mode = (data.answerMode as any) || 'standard';

    return {
      title: `${subject}: ${chapter}`,
      mode,
      directAnswer: `In ICSE ${subject}, "${question}" requires analyzing the foundational definition, governing equations, and experimental or geometrical proof.`,
      concept: `The core concept in ${chapter} requires distinguishing primary physical/mathematical definitions from secondary derived formulas. Always establish the baseline laws before substituting values.`,
      explanation: `To master ${question}, begin by establishing the given parameters in standard SI units. State the governing formula clearly. Show intermediate algebraic steps explicitly rather than performing mental jumps.`,
      whyItWorks: `Physical and mathematical systems obey conservation principles and dimensional consistency. Each term in your equation must possess identical dimensions to maintain scientific validity.`,
      steps: [
        'Write down the given state variables with units.',
        'State the primary ICSE textbook law or formula governing the system.',
        'Substitute values step-by-step into the equation with clear bracket preservation.',
        'Compute the final numerical magnitude accompanied by correct standard units.'
      ],
      workedExample: `Example problem: A particle with initial velocity u = 0 accelerates uniformly at a = 2 m/s² for t = 5 s. Using v = u + at, final velocity v = 0 + (2)(5) = 10 m/s.`,
      diagram: `Initial State (t=0s)           Uniform Acceleration (a)           Final State (t=5s)\n[u = 0 m/s] ---------------------> [a = 2 m/s²] ---------------------> [v = 10 m/s]`,
      commonMistakes: [
        'Skipping units in the final numerical answer, which forfeits 1 mark under ICSE criteria.',
        'Performing mental calculations without writing intermediate bracket operations.'
      ],
      examTips: [
        'Always write the formula in standard algebraic symbols before numerical substitution.',
        'Underline or box the final answer with its standard SI unit.'
      ],
      checkYourself: [
        'If the time elapsed were doubled while keeping acceleration constant, what would happen to the final velocity?'
      ],
      summary: `Mastering ${question} in ${chapter} requires explicit step layout, dimensional consistency, and strict SI unit adherence.`,
      nextAction: 'Solve 3 numerical problems from your ICSE textbook under timed 15-minute conditions.'
    };
  }

  // 1. RECOMMEND PRIORITIES (Strict 7-tier hierarchy)
  private static recommendPriorities(data: Record<string, unknown>): StructuredPriorityResponse {
    const mathsCompleted = Number(data.mathsCompleted || 0);
    const overdueRevisions = (data.overdueRevisions as Array<{ subject: string; topic: string; intervalDay: number }>) || [];
    const urgentDoubts = (data.urgentDoubts as Array<{ subject: string; question: string }>) || [];
    const examOverrides = (data.examOverrides as Array<{ subject: string; examName: string; examDate: string }>) || [];
    const totalMinutesCompleted = Number(data.totalMinutesCompleted || 0);
    const targetTotal = Number(data.targetMinutesTotal || 210);
    const isWeekend = Boolean(data.isWeekendAcademyDay);

    const priorities: StructuredPriorityResponse['priorities'] = [];

    // Tier 1: Maths incomplete today (<60 mins)
    if (mathsCompleted < 60) {
      const remaining = 60 - mathsCompleted;
      priorities.push({
        priority: 'P1: Mandatory Morning Mathematics Quota',
        reason: `StudyOS core rule requires 60 minutes of Mathematics daily. You currently have logged ${mathsCompleted}/60m (${remaining}m deficit).`,
        duration: `${remaining} minutes`,
        action: 'Close all video tabs. Open ICSE textbook (Selina/Concise) and independently solve numerical sums under timed desk conditions.',
        proofOfCompletion: 'Logged study session with >=8 questions attempted and accuracy calculated.',
      });
    }

    // Tier 2: Revision overdue (+1, +3, +7)
    if (overdueRevisions.length > 0) {
      const topRev = overdueRevisions[0];
      priorities.push({
        priority: `P2: Spaced Retrieval (+${topRev.intervalDay}d Due): ${topRev.subject}`,
        reason: `Scheduled deterministic retrieval for ${topRev.topic}. If not tested within 24h of the due window, neural consolidation decays rapidly.`,
        duration: '20 minutes',
        action: 'Close notes completely. Write out the problem and re-derive the solution without looking at your previous mistake log.',
        proofOfCompletion: 'Mark revision as verified in the Mistake Logbook with concise check notes.',
      });
    }

    // Tier 3: Upcoming exam urgency
    if (examOverrides.length > 0) {
      const exam = examOverrides[0];
      priorities.push({
        priority: `P3: Urgent Exam Preparation: ${exam.subject}`,
        reason: `Active exam override detected for "${exam.examName}" scheduled on ${exam.examDate}.`,
        duration: '60 minutes',
        action: `Execute targeted problem sets or past 5-year ICSE board specimen papers for ${exam.subject}.`,
        proofOfCompletion: 'Completed timed exam drill with marking scheme comparison.',
      });
    }

    // Tier 4: Unresolved high-priority doubt
    if (urgentDoubts.length > 0) {
      const topDoubt = urgentDoubts[0];
      priorities.push({
        priority: `P4: Clear High-Priority Doubt: ${topDoubt.subject}`,
        reason: `Pending concept blockage: "${topDoubt.question}". Studying advanced topics before clearing fundamentals produces repeated errors.`,
        duration: '15 minutes',
        action: 'Review ICSE standard definitions or teacher explanations. Record the correct derivation in the Doubt Inbox.',
        proofOfCompletion: 'Doubt status updated to Solved with resolution note.',
      });
    }

    // Tier 5/6/7: Study-time deficit to hit 3.5h (210 mins)
    if (totalMinutesCompleted < targetTotal) {
      const deficit = targetTotal - totalMinutesCompleted;
      priorities.push({
        priority: 'P5: Core Subject Deep Work Block',
        reason: `Daily focused study target is 3.5 hours (210m). Currently at ${Math.round((totalMinutesCompleted / 60) * 10) / 10}h (${deficit}m to baseline).`,
        duration: `${Math.min(60, deficit)} minutes`,
        action: 'Execute your rotating schedule subject block (Physics/Chemistry/Biology) with active recall intervals.',
        proofOfCompletion: 'Timer completed at study desk with active note check.',
      });
    }

    // Tier fallback if everything is on track
    if (priorities.length === 0) {
      priorities.push({
        priority: 'P1: Daily Targets Fulfilled — Reading & Skill Lab',
        reason: 'You have achieved your mandatory 60m Maths block and your 3.5h core study target.',
        duration: '30–45 minutes',
        action: 'Read 5+ pages of non-fiction or work on your Python / AI Agent / Robotics skill project.',
        proofOfCompletion: 'Logged reading pages in the Reading Log or committed code in Skill Lab.',
      });
    }

    return {
      title: 'Deterministic StudyOS Daily Execution Priorities',
      overallAssessment: isWeekend
        ? 'Weekend Academy Day: Academy runs 4:00 PM – 7:30 PM. Front-load your P1 and P2 priorities before 3:30 PM!'
        : 'Class 9 ICSE Academic Comeback: Maintain zero skipped Maths days and strict error revivals.',
      priorities: priorities.slice(0, 4),
      cautionNote:
        'Never study lying in bed or watching passive video playlists. Work seated upright with pen and notebook.',
    };
  }

  // 2. EXPLAIN A DOUBT (Socratic & Structured)
  private static explainDoubt(data: Record<string, unknown>): StructuredDoubtResponse {
    const question = String(data.question || 'Conceptual query');
    const subject = String(data.subject || 'Academic Subject');
    const chapter = String(data.chapter || 'Core Chapter');

    return {
      whatQuestionIsTesting: `This question evaluates your foundational comprehension of ${chapter} in ICSE ${subject}, specifically testing whether you can distinguish the core physical principle from formula manipulation.`,
      hint: `Before looking at formulas, ask yourself: what physical quantity or mathematical property remains invariant (constant) in this scenario?`,
      stepByStepExplanation: `1. Identify the given parameters and state variables in standard SI units.\n2. Write down the governing law or identity applicable to ${chapter} (e.g. conservation of momentum, Newton's laws, or algebraic expansions).\n3. Re-examine the transition where confusion occurred: often students overlook implicit constraints (e.g. constant acceleration, right angles, or sign conventions).\n4. Substitute values step-by-step without skipping intermediate bracket steps.`,
      checkYourselfQuestion: `If the initial value or condition were doubled while keeping other factors constant, would your derived result double, quadruple, or stay invariant?`,
      whetherToAddToRevision: true,
      revisionAdvice: `Add this to your +1d and +3d revision queue so you test yourself on this exact concept tomorrow without consulting this solution.`,
      socraticQuestions: [
        'What definition in the ICSE textbook defines this concept in one sentence?',
        'What units must each term have for dimensional consistency?',
        'Can you draw a rough sketch or free-body diagram showing all acting components?',
      ],
    };
  }

  // 3. ANALYZE A MISTAKE (Root cause categorization)
  private static analyzeMistake(data: Record<string, unknown>): StructuredMistakeAnalysisResponse {
    const subject = String(data.subject || 'Mathematics');
    const chapterTopic = String(data.chapterTopic || 'Problem Sums');
    const errorCategory = String(data.errorCategory || 'Calculation Error');
    const wrongApproach = String(data.wrongApproach || 'Missed step in derivation');
    const correctMethod = String(data.correctMethod || 'Standard ICSE textbook method');
    const isRepeated = Boolean(data.isRepeated);

    return {
      rootCauseCategory: errorCategory,
      whyMarksLost: `Marks were lost due to a ${errorCategory} during ${chapterTopic}. The incorrect step ("${wrongApproach}") shows an execution breakdown rather than total absence of knowledge.`,
      keyMisconception: `Assuming you could compute the step mentally or skip explicit layout of brackets and signs. In ICSE evaluation, step-marking penalizes skipped working.`,
      correctProcedure: correctMethod || 'Write down the formal identity, substitute values with brackets, and double-check sign transitions before computing.',
      retrievalTriggerQuestion: `When encountering problems of type "${chapterTopic}", what is the very first rule you must write down on your paper before writing numbers?`,
      scheduleRevisionRecommendation: isRepeated
        ? 'CRITICAL REPEATED MISTAKE: Scheduled for mandatory +1d and +3d retrieval. You must solve 3 parallel textbook problems without any hints.'
        : 'Scheduled for standard +1d, +3d, and +7d spaced retrieval.',
      preventiveHabit: 'Slow down by 5 seconds during the substitution step. Write the formula in words or symbols first before plugging in numerical values.',
    };
  }

  // 4. GENERATE RETRIEVAL QUIZ (Short 3-Question Active Recall Set)
  private static generateQuiz(data: Record<string, unknown>): StructuredQuizResponse {
    const subject = String(data.subject || 'Mathematics');
    const topic = String(data.topic || 'ICSE Core Topic');

    return {
      subject,
      topic,
      title: `3-Minute Independent Retrieval Quiz: ${topic}`,
      evidenceNotice: 'Solve these 3 questions with closed notes under a 5-minute timer. Never claim mastery without verified written answers.',
      questions: [
        {
          id: 'q1',
          question: `State the fundamental law or governing algebraic identity defining "${topic}" in ICSE ${subject}.`,
          hint: 'Focus on exact mathematical formulation or verbatim textbook definition.',
          standardSolution: `The standard governing statement must include all prerequisite conditions (e.g. constant temperature for Boyle\'s law, or standard ax^2+bx+c=0 form for quadratic expressions).`,
          icseMarkingPoints: ['Accurate definition/identity (1 mark)', 'Conditions of validity (1 mark)'],
        },
        {
          id: 'q2',
          question: `A typical problem in ${topic} has a trap involving sign transposition or unit conversion. Describe the trap and how to neutralize it.`,
          hint: 'Think about SI units (grams vs kilograms, cm vs m) or negative sign distribution across parentheses.',
          standardSolution: 'Always enforce unit conversion at the top of the working column: convert all data to SI units before substituting into the equation.',
          icseMarkingPoints: ['Explicit identification of trap (1 mark)', 'Correct conversion step (1 mark)'],
        },
        {
          id: 'q3',
          question: `Solve an independent numerical or proof step for ${topic} with timer running. What is your check step?`,
          hint: 'Can you back-substitute your answer into the original problem statement?',
          standardSolution: 'Back-substitute the final numerical value into the original LHS to verify it equals RHS.',
          icseMarkingPoints: ['Correct calculation steps (2 marks)', 'Verification check written (1 mark)'],
        },
      ],
    };
  }

  // 5. CONDUCT WEEKLY REVIEW (Strictly real data assessment)
  private static conductWeeklyReview(data: Record<string, unknown>): Record<string, unknown> {
    const totalHours = Number(data.totalStudyHours || 0);
    const mathsDays = Number(data.mathsDaysCompleted || 0);
    const accuracy = Number(data.accuracyAverage || 0);
    const repeated = Number(data.repeatedMistakesCount || 0);
    const doubts = Number(data.unresolvedDoubtsCount || 0);

    const critique: string[] = [];
    if (mathsDays < 7) {
      critique.push(`Maths discipline failed on ${7 - mathsDays} days. Mathematics is mandatory every single day for 60 minutes.`);
    } else {
      critique.push('Perfect 7/7 Mathematics consistency maintained. This is the foundation of academic recovery.');
    }

    if (totalHours < 24.5) {
      critique.push(`Study deficit: ${totalHours}h completed vs 24.5h target (${Math.round((24.5 - totalHours) * 10) / 10}h deficit).`);
    }

    if (repeated > 0) {
      critique.push(`Warning: ${repeated} repeated mistakes logged. You are looking at solutions without forcing yourself to re-solve them closed-book.`);
    }

    if (doubts > 0) {
      critique.push(`${doubts} doubts remain unresolved. Allocate your evening recall block to eliminate them.`);
    }

    return {
      title: 'Honest Weekly Academic Audit',
      totalStudyHours: totalHours,
      mathsDaysCompleted: mathsDays,
      accuracyAverage: `${accuracy}%`,
      verdict: mathsDays >= 6 && totalHours >= 21 ? 'Discipline on Track' : 'Academic Deficit Detected',
      coachingCritique: critique,
      nextWeekPrescription:
        '1. Front-load Morning Maths at 06:00 AM before school.\n2. Do not skip evening 30m error logging.\n3. On weekend academy days (Sat/Sun), finish 3.5h before 03:30 PM.',
    };
  }

  // 6. SOCRATIC QUESTIONING
  private static socraticQuestion(data: Record<string, unknown>): Record<string, unknown> {
    const concept = String(data.conceptOrDoubt || 'the concept');
    return {
      title: 'Socratic Inquiry',
      concept,
      guidance: 'I will not give you the final answer directly, because true neural mastery requires independent retrieval.',
      guidingQuestions: [
        `What is the underlying physical or mathematical property behind ${concept}?`,
        'Can you write down what is given and what you need to find in separate columns?',
        'If you change only one variable, how do the others respond?',
        'Which textbook chapter theorem connects these two quantities directly?',
      ],
      nextStep: 'Reply with your answers to these 4 questions, and we will pinpoint the exact missing link.',
    };
  }

  // 7. WEAK TOPIC 3-DAY PLAN
  private static generateWeakTopicPlan(data: Record<string, unknown>): StructuredWeakTopicPlanResponse {
    const subject = String(data.subject || 'Mathematics');
    const topic = String(data.weakTopic || 'Weak Topic');

    return {
      subject,
      topic,
      diagnosis: `Topic "${topic}" exhibits recurrent errors or low question accuracy. A 3-day focused micro-plan is required to turn this into a high-confidence area.`,
      targetProof: 'Solve 10 random ICSE past year questions from this topic with >85% accuracy under 45 minutes.',
      threeDayPlan: [
        {
          dayNumber: 1,
          phase: 'Retrieve',
          focus: 'Formulas, standard proofs & error category inventory',
          durationMinutes: 45,
          action: `Write out all definitions and formulas for ${topic} from memory. Check against notes and repair blind spots.`,
          proof: '100% of formulas written without reference.',
        },
        {
          dayNumber: 2,
          phase: 'Repair & Produce',
          focus: 'Standard textbook problem solving with timer',
          durationMinutes: 60,
          action: 'Solve 8 medium-to-hard textbook problems independently. Log every lost mark into the 6 error categories.',
          proof: 'Written working with 0 unverified steps.',
        },
        {
          dayNumber: 3,
          phase: 'Timed Retest',
          focus: 'Closed-book examination conditions',
          durationMinutes: 45,
          action: 'Solve 6 mixed past-year board questions under exam conditions with no notes in the room.',
          proof: 'Marking scheme comparison score >=85%.',
        },
      ],
    };
  }

  // 8. SKILL LAB PLAN
  private static generateSkillPlan(data: Record<string, unknown>): StructuredSkillPlanResponse {
    const track = String(data.targetTrack || 'Python Programming & AI Agents');

    return {
      skillTrack: track,
      weeklyTargetHours: 4,
      roadmapLevel: 'Class 9 High-Leverage Builder',
      milestones: [
        {
          title: 'Core Fundamentals & Algorithmic Practice',
          actionableDrillOrCode: 'Implement 5 fundamental algorithmic problems (loops, conditionals, string manipulations) in clean Python.',
          timeMinutes: 60,
          tangibleDeliverable: 'Working python script with zero syntax errors.',
        },
        {
          title: 'Agent Architecture & Tool Calling',
          actionableDrillOrCode: 'Build a small CLI script that defines tools, executes user queries, and formats outputs.',
          timeMinutes: 90,
          tangibleDeliverable: 'Local agent loop prototype running in terminal.',
        },
        {
          title: 'Physical / Hardware Interface or Quantum Conceptual Model',
          actionableDrillOrCode: 'Map how classical computing logic gates differ from quantum superposition principles or microcontroller I/O.',
          timeMinutes: 60,
          tangibleDeliverable: 'One-page technical design summary and demo code.',
        },
      ],
    };
  }
}
