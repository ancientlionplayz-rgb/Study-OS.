'use client';

import React, { useState } from 'react';
import {
  RotateCcw,
  CheckCircle2,
  Clock,
  Calendar,
  AlertOctagon,
  Sparkles,
} from 'lucide-react';
import { useStudyOS } from '../../lib/storage/context';
import { RevisionTask } from '../../types';

export function RevisionQueue() {
  const { revisionsDue, completeRevision, snoozeRevision, reattemptRevision } = useStudyOS();
  const [completedNotes, setCompletedNotes] = useState<Record<string, string>>({});
  const [activeNoteInputId, setActiveNoteInputId] = useState<string | null>(null);

  if (revisionsDue.length === 0) {
    return (
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-center">
        <div className="flex items-center justify-center gap-2 text-xs text-emerald-400 font-semibold mb-1">
          <CheckCircle2 className="w-4 h-4" />
          <span>Revision Queue Up To Date</span>
        </div>
        <p className="text-[11px] text-slate-400">
          All +1d, +3d, and +7d deterministic retrieval tasks are completed for today.
        </p>
      </div>
    );
  }

  const handleComplete = (task: RevisionTask) => {
    const note = completedNotes[task.id];
    completeRevision(task.id, note);
    setActiveNoteInputId(null);
  };

  return (
    <div className="rounded-2xl border border-rose-500/30 bg-gradient-to-br from-rose-950/20 via-slate-900 to-slate-900 p-5 shadow-xl space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <RotateCcw className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span>Deterministic Revision Queue (+1, +3, +7)</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                {revisionsDue.length} Due
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Spaced retrieval scheduled automatically upon logging mistakes — test without looking at notes
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2.5">
        {revisionsDue.map((task) => (
          <div
            key={task.id}
            className="rounded-xl border border-slate-800 bg-slate-850/80 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  +{task.intervalDay} Day Retrieval
                </span>
                <span className="text-xs font-bold text-brand-blue">{task.subject}</span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-400 text-[11px] font-mono">Due: {task.dueDate}</span>
              </div>
              <div className="text-slate-200 font-semibold">{task.topic}</div>

              {activeNoteInputId === task.id && (
                <div className="mt-2">
                  <input
                    type="text"
                    placeholder="Brief retest notes (e.g. solved in 3 mins without error)..."
                    value={completedNotes[task.id] || ''}
                    onChange={(e) =>
                      setCompletedNotes({ ...completedNotes, [task.id]: e.target.value })
                    }
                    className="w-full px-2.5 py-1.5 rounded bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              {activeNoteInputId !== task.id ? (
                <button
                  onClick={() => setActiveNoteInputId(task.id)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verify</span>
                </button>
              ) : (
                <button
                  onClick={() => handleComplete(task)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors"
                >
                  Done
                </button>
              )}

              <button
                onClick={() => snoozeRevision(task.id, 1)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-colors"
                title="Snooze +1 day"
              >
                Snooze (+1d)
              </button>

              <button
                onClick={() => reattemptRevision(task.id)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-colors"
                title="Schedule immediate reattempt"
              >
                Reattempt
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
